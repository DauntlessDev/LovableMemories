package com.example.lovablememories;

import android.media.MediaPlayer;

public class Music {
    static MediaPlayer mediaPlayer;
}
